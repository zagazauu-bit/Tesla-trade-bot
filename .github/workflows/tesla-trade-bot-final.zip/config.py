BOT_TOKEN = "YOUR_TELEGRAM_BOT_API_TOKEN"
ALPACA_API_KEY = "YOUR_ALPACA_API_KEY"
ALPACA_SECRET_KEY = "YOUR_ALPACA_SECRET_KEY"
BASE_URL = "https://paper-api.alpaca.markets"  # use paper trading
ADMIN_ID = 123456789  # replace with your Telegram ID from /whoami
