import yfinance as yf
import alpaca_trade_api as tradeapi
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters
from config import BOT_TOKEN, ALPACA_API_KEY, ALPACA_SECRET_KEY, BASE_URL, ADMIN_ID

# Alpaca API
api = tradeapi.REST(ALPACA_API_KEY, ALPACA_SECRET_KEY, BASE_URL, api_version="v2")

# Alerts storage
alerts = {}  # chat_id -> list of (price, action)

# --- Menu Keyboard ---
menu_keyboard = [
    ["📊 Tesla Price", "📦 Position"],
    ["✅ Buy 1 Share", "❌ Sell 1 Share"],
    ["🔔 Set Alert", "📈 Strategy On", "⏹ Strategy Off"]
]
reply_markup = ReplyKeyboardMarkup(menu_keyboard, resize_keyboard=True)

# --- Start Command ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🚀 Welcome to Tesla Trade Bot!\nChoose an option:",
        reply_markup=reply_markup
    )

# --- Alerts Commands ---
async def set_alert(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    try:
        price = float(context.args[0])
        action = context.args[1].lower()
        if action not in ["buy", "sell"]:
            await update.message.reply_text("⚠️ Use: /setalert <price> <buy/sell>")
            return
        alerts.setdefault(chat_id, []).append((price, action))
        await update.message.reply_text(f"🔔 Alert set: {action.upper()} if TSLA reaches ${price:.2f}")
    except Exception:
        await update.message.reply_text("⚠️ Correct format: /setalert 250 buy")

async def my_alerts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    if chat_id not in alerts or not alerts[chat_id]:
        await update.message.reply_text("ℹ️ You have no alerts set.")
    else:
        msg = "📋 Your alerts:\n"
        for price, action in alerts[chat_id]:
            msg += f"- {action.upper()} at ${price}\n"
        await update.message.reply_text(msg)

async def clear_alerts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat_id = update.effective_chat.id
    alerts.pop(chat_id, None)
    await update.message.reply_text("🧹 All alerts cleared.")

async def check_alerts(context: ContextTypes.DEFAULT_TYPE):
    stock = yf.Ticker("TSLA")
    price = stock.history(period="1d")["Close"].iloc[-1]

    for chat_id, user_alerts in list(alerts.items()):
        triggered = []
        for alert_price, action in user_alerts:
            if action == "buy" and price <= alert_price:
                api.submit_order("TSLA", qty=1, side="buy", type="market", time_in_force="gtc")
                await context.bot.send_message(chat_id, f"✅ Auto-BUY: TSLA at ${price:.2f}")
                triggered.append((alert_price, action))
            elif action == "sell" and price >= alert_price:
                api.submit_order("TSLA", qty=1, side="sell", type="market", time_in_force="gtc")
                await context.bot.send_message(chat_id, f"✅ Auto-SELL: TSLA at ${price:.2f}")
                triggered.append((alert_price, action))
        for t in triggered:
            user_alerts.remove(t)

# --- Handle Button Presses ---
async def handle_buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text

    if text == "📊 Tesla Price":
        stock = yf.Ticker("TSLA")
        price = stock.history(period="1d")["Close"].iloc[-1]
        await update.message.reply_text(f"📊 Tesla (TSLA): ${price:.2f}")

    elif text == "📦 Position":
        try:
            positions = api.list_positions()
            for pos in positions:
                if pos.symbol == "TSLA":
                    await update.message.reply_text(
                        f"📦 Tesla Holdings:\nShares: {pos.qty}\nValue: ${pos.market_value}"
                    )
                    return
            await update.message.reply_text("⚠️ No Tesla shares held.")
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {e}")

    elif text == "✅ Buy 1 Share":
        try:
            api.submit_order("TSLA", qty=1, side="buy", type="market", time_in_force="gtc")
            await update.message.reply_text("✅ Bought 1 Tesla share.")
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {e}")

    elif text == "❌ Sell 1 Share":
        try:
            api.submit_order("TSLA", qty=1, side="sell", type="market", time_in_force="gtc")
            await update.message.reply_text("✅ Sold 1 Tesla share.")
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {e}")

    elif text == "📈 Strategy On":
        context.chat_data["strategy"] = True
        await update.message.reply_text("📈 Auto-strategy ENABLED ✅")

    elif text == "⏹ Strategy Off":
        context.chat_data["strategy"] = False
        await update.message.reply_text("⏹ Auto-strategy DISABLED ❌")

    # --- Admin Only Commands ---
    elif text == "/stopbot":
        if update.effective_user.id == ADMIN_ID:
            await update.message.reply_text("🛑 Bot stopped by admin.")
            raise SystemExit
        else:
            await update.message.reply_text("🚫 Unauthorized command.")

    elif text == "/reset":
        if update.effective_user.id == ADMIN_ID:
            context.chat_data.clear()
            await update.message.reply_text("♻️ Bot memory reset.")
        else:
            await update.message.reply_text("🚫 Unauthorized command.")

# --- Main ---
def main():
    app = Application.builder().token(BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("setalert", set_alert))
    app.add_handler(CommandHandler("myalerts", my_alerts))
    app.add_handler(CommandHandler("clearalerts", clear_alerts))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_buttons))

    job_queue = app.job_queue
    job_queue.run_repeating(check_alerts, interval=60, first=10)

    app.run_polling()

if __name__ == "__main__":
    main()
