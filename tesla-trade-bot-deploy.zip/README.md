# Tesla Trade Bot (Deploy Ready)

A Telegram bot that trades Tesla (TSLA) stock using Alpaca API.

## Features
- Get Tesla stock price
- Buy/sell shares
- Account balance & buying power (/account)
- Set price alerts with auto-trading
- Moving Average strategy (SMA5/SMA20)
- Trade logging
- Admin-only commands

## Setup (Local)
1. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
2. Set environment variables (example):
   ```bash
   export BOT_TOKEN="your_telegram_token"
   export ALPACA_API_KEY="your_key"
   export ALPACA_SECRET_KEY="your_secret"
   export ADMIN_ID=123456789
   ```
3. Run:
   ```bash
   python bot.py
   ```

## Deploy to Render
- Push this repo to GitHub
- Create a new **Web Service** on Render
- Set environment variables in Render dashboard
- Start command is handled by `Procfile`

## Deploy to Heroku
```bash
heroku create
heroku buildpacks:add heroku/python
heroku config:set BOT_TOKEN=xxx ALPACA_API_KEY=xxx ALPACA_SECRET_KEY=xxx ADMIN_ID=123456
git push heroku main
```
