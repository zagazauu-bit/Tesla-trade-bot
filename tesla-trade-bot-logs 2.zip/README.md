# Tesla Trade Bot 🚀

A Telegram bot to track and trade Tesla (TSLA) stock in real-time.

## Features
- 📊 Live Tesla stock price
- ✅ Buy/Sell shares directly via Alpaca (paper trading first!)
- 🔔 Price alerts with auto-trade (/setalert, /myalerts, /clearalerts)
- 📈 Auto-trading strategies (basic toggle)
- 🔒 Admin-only commands (/stopbot, /reset)

## Setup
1. Clone this repo or unzip the package
2. Install dependencies:
   ```bash
   pip install -r requirements.txt
   ```
3. Edit `config.py` and add your Telegram Bot Token + Alpaca keys
4. Run:
   ```bash
   python bot.py
   ```

## Deployment
- Local: run `python bot.py`
- VPS: keep running with `screen` or `pm2`
- Cloud: deploy to Heroku, AWS, or DigitalOcean

⚠️ WARNING: Never share your `BOT_TOKEN` or API keys publicly!
