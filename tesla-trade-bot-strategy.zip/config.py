# --- Fill in your API tokens below ---

BOT_TOKEN = "YOUR_NEW_TELEGRAM_BOT_TOKEN"

ALPACA_API_KEY = "YOUR_ALPACA_API_KEY"
ALPACA_SECRET_KEY = "YOUR_ALPACA_SECRET_KEY"
BASE_URL = "https://paper-api.alpaca.markets"

# Replace with your Telegram user ID (for admin commands)
ADMIN_ID = 123456789
