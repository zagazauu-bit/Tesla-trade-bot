import yfinance as yf
import alpaca_trade_api as tradeapi
from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, ContextTypes, filters
from config import BOT_TOKEN, ALPACA_API_KEY, ALPACA_SECRET_KEY, BASE_URL, ADMIN_ID

# Alpaca API
api = tradeapi.REST(ALPACA_API_KEY, ALPACA_SECRET_KEY, BASE_URL, api_version="v2")

# --- Menu Keyboard ---
menu_keyboard = [
    ["📊 Tesla Price", "📦 Position"],
    ["✅ Buy 1 Share", "❌ Sell 1 Share"],
    ["🔔 Set Alert", "📈 Strategy On", "⏹ Strategy Off"]
]
reply_markup = ReplyKeyboardMarkup(menu_keyboard, resize_keyboard=True)

# --- Start Command ---
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "🚀 Welcome to Tesla Trade Bot!\nChoose an option:",
        reply_markup=reply_markup
    )

# --- Handle Button Presses ---
async def handle_buttons(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text

    if text == "📊 Tesla Price":
        stock = yf.Ticker("TSLA")
        price = stock.history(period="1d")["Close"].iloc[-1]
        await update.message.reply_text(f"📊 Tesla (TSLA): ${price:.2f}")

    elif text == "📦 Position":
        try:
            positions = api.list_positions()
            for pos in positions:
                if pos.symbol == "TSLA":
                    await update.message.reply_text(
                        f"📦 Tesla Holdings:\nShares: {pos.qty}\nValue: ${pos.market_value}"
                    )
                    return
            await update.message.reply_text("⚠️ No Tesla shares held.")
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {e}")

    elif text == "✅ Buy 1 Share":
        try:
            api.submit_order("TSLA", qty=1, side="buy", type="market", time_in_force="gtc")
            await update.message.reply_text("✅ Bought 1 Tesla share.")
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {e}")

    elif text == "❌ Sell 1 Share":
        try:
            api.submit_order("TSLA", qty=1, side="sell", type="market", time_in_force="gtc")
            await update.message.reply_text("✅ Sold 1 Tesla share.")
        except Exception as e:
            await update.message.reply_text(f"❌ Error: {e}")

    elif text == "📈 Strategy On":
        context.chat_data["strategy"] = True
        await update.message.reply_text("📈 Auto-strategy ENABLED ✅")

    elif text == "⏹ Strategy Off":
        context.chat_data["strategy"] = False
        await update.message.reply_text("⏹ Auto-strategy DISABLED ❌")

    # --- Admin Only Commands ---
    elif text == "/stopbot":
        if update.effective_user.id == ADMIN_ID:
            await update.message.reply_text("🛑 Bot stopped by admin.")
            raise SystemExit
        else:
            await update.message.reply_text("🚫 Unauthorized command.")

    elif text == "/reset":
        if update.effective_user.id == ADMIN_ID:
            context.chat_data.clear()
            await update.message.reply_text("♻️ Bot memory reset.")
        else:
            await update.message.reply_text("🚫 Unauthorized command.")

# --- Main ---
def main():
    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_buttons))
    app.run_polling()

if __name__ == "__main__":
    main()
